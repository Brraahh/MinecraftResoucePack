Brraahh Discord HD Chat Test Pack
This pack intentionally changes the default Minecraft font clearly so you can confirm it works.
Upload this ZIP to GitHub and update server.properties resource-pack URL.
