Brraahh Safe Discord-ish Chat Font v2
This is a safer compact font test. It changes the Minecraft font globally, but should not explode spacing like the previous test.
Upload to GitHub and update the resource-pack URL when ready.
